
ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "Barriss Offee's Starfighter (Delta-7)"
ENT.Author = "ϟLightning Boltϟ"
ENT.Information = ""
ENT.Category = "[LFS] Star Wars"

ENT.Spawnable		= true
ENT.AdminSpawnable		= false
ENT.Editable = false

ENT.MDL = "models/starwars/lordtrilobite/ships/delta7/delta7_landed.mdl"

ENT.GibModels = {
	"models/XQM/wingpiece2.mdl",
	"models/XQM/wingpiece2.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/props_c17/TrapPropeller_Engine.mdl",
	"models/props_junk/Shoe001a.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 2

ENT.Mass = 2000
ENT.Inertia = Vector(150000,150000,150000)
ENT.Drag = 1

ENT.SeatPos = Vector(-105,-0,29)
ENT.SeatAng = Angle(1.5,-95,15)

ENT.IdleRPM = 0
ENT.MaxRPM = 2800
ENT.LimitRPM = 3000

ENT.RotorPos = Vector(129.14,0,27.31)
ENT.WingPos = Vector(-51.92,0,25.02)
ENT.ElevatorPos = Vector(-450,0,52.05)
ENT.RudderPos = Vector(-450,0,68)

ENT.MaxVelocity = 2850

ENT.MaxThrust = 28000

ENT.MaxTurnPitch = 1090
ENT.MaxTurnYaw = 500
ENT.MaxTurnRoll = 500

ENT.MaxPerfVelocity = 1500

ENT.MaxHealth = 1300
ENT.MaxShield = 500

ENT.Stability = 0.7

ENT.VerticalTakeoff = true
ENT.VtolAllowInputBelowThrottle = 10
ENT.MaxThrustVtol = 10000

ENT.MaxPrimaryAmmo = 3000
ENT.MaxSecondaryAmmo = -1

sound.Add( {
	name = "JEDISF_FIRE",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 100,
	pitch = {95, 105},
	sound = "lfs/jsf/TIE Laser 2D.mp3"
} )

sound.Add( {
	name = "JEDISF_ENGINE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/JSF ENG 1B.wav"
} )

sound.Add( {
	name = "JEDISF_DIST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/JSF ENG 2.wav"
} )

sound.Add( {
	name = "JEDISF_BOOST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/JSF Flyby 1.mp3"
} )

sound.Add( {
	name = "JEDISF_BRAKE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/JSF Flyby 2.mp3"
} )