
ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "Obi-Wan Kenobi's Starfighter (Eta-2)"
ENT.Author = "ϟLightning Boltϟ"
ENT.Information = ""
ENT.Category = "[LFS] Star Wars"

ENT.Spawnable		= true
ENT.AdminSpawnable		= false
ENT.Editable = false

ENT.MDL = "models/eta2r/eta2r1.mdl"

ENT.GibModels = {
	"models/XQM/wingpiece2.mdl",
	"models/XQM/wingpiece2.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/props_c17/TrapPropeller_Engine.mdl",
	"models/props_junk/Shoe001a.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 2

ENT.Mass = 2000
ENT.Inertia = Vector(150000,150000,150000)
ENT.Drag = 1

ENT.SeatPos = Vector(-20,-1.5,15)
ENT.SeatAng = Angle(0,-95,0)

ENT.IdleRPM = 0
ENT.MaxRPM = 2800
ENT.LimitRPM = 3200

ENT.RotorPos = Vector(-10,0,0)
ENT.WingPos = Vector(100,0,0)
ENT.ElevatorPos = Vector(-300,0,0)
ENT.RudderPos = Vector(-300,0,0)

ENT.MaxVelocity = 3100

ENT.MaxThrust = 50000

ENT.MaxTurnPitch = 1200
ENT.MaxTurnYaw = 1500
ENT.MaxTurnRoll = 500

ENT.MaxPerfVelocity = 1500

ENT.MaxHealth = 1300
ENT.MaxShield = 0

ENT.Stability = 0.7

ENT.VerticalTakeoff = true
ENT.VtolAllowInputBelowThrottle = 10
ENT.MaxThrustVtol = 10000

ENT.MaxPrimaryAmmo = 3000
ENT.MaxSecondaryAmmo = 800

ENT.DroidModels = {
	"models/nicholasray/sws/r2d2r.mdl",
	"models/nicholasray/sws/r2d2g.mdl",
	"models/nicholasray/sws/r2d2b.mdl",
};

function ENT:SpawnDroid(pos)
	
	local e = ents.Create("prop_physics");
	e:SetModelScale(0.775);
	e:SetModel(self.CurrentDroid);
	e:SetPos(pos);
	e:SetAngles(self:GetAngles()+Angle(0,0,-10));
	e:SetParent(self);
	e:Spawn();
	e:Activate();
	e:GetPhysicsObject():EnableMotion(false);
	e:GetPhysicsObject():EnableCollisions(false);
	e:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE )
	self.Droid = e;

end

sound.Add( {
	name = "JEDISF_FIRE",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 100,
	pitch = {95, 105},
	sound = "lfs/jsf/TIE Laser 2D.mp3"
} )

sound.Add( {
	name = "JEDISF_FIRE2",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = 100,
	pitch = {95, 105},
	sound = "lfs/jsf/AT-AT Cannon 1.mp3"
} )

sound.Add( {
	name = "ETA2_ENGINE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/ETAENG.wav"
} )

sound.Add( {
	name = "ETA2_DIST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/ETAENGDIST.wav"
} )

sound.Add( {
	name = "ETA2_BOOST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/Boost.mp3"
} )

sound.Add( {
	name = "ETA2_BRAKE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 100,
	sound = "lfs/jsf/Brake.mp3"
} )
